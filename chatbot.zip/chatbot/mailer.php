<?php
    // SOLO PETICIONES DEL METODO POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // OBTENER LOS CAMPOS DEL FORMULARIO Y REMOVER ESPACIOS EN BLANCO
        $name = strip_tags(trim($_POST["name"]));
        $name = str_replace(array("\r","\n"),array(" "," "),$name);
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL); 
        $phone = trim($_POST["phone_number"]);
        $message = trim($_POST["message"]);

        // Chequea si la data fue enviada al email.
        if ( empty($name) OR empty($phone) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            http_response_code(400);
            echo "Hay un problema con tu petición, porfavor intenta de nuevo.";
            exit;
        }

        // EMAIL A ENVIAR
        // FIXME: Update this to your desired email address.
        $recipient = "iamthonycd@gmail.com";

        // Sujeto del email.
        $subject = "Neuron Contact From $name";

        // Contenido del email.
        $email_content = "Nombre: $name\n";
        $email_content .= "Email: $email\n";
        $email_content .= "Teléfono: $phone\n\n";
        $email_content .= "Mensaje:\n$message\n";

        // Encabezado del email.
        $email_headers = "De: $name <$email>";

        // Enviar el email.
        if (mail($recipient, $subject, $email_content, $email_headers)) {
            // Set a 200 (okay) response code.
            http_response_code(200);
            echo "Gracias! Tu mensaje ha sido enviado.";
        } else {
            // Set a 500 (internal server error) response code.
            http_response_code(500);
            echo "Oops! Algo salió mal y tu mensaje no pudo ser enviado.";
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        http_response_code(403);
        echo "Hay un problema con tu petición, porfavor intenta de nuevo.";
    }

?>
